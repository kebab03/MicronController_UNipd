/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f1xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f1xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/*
	Uncomment the chosen controller type: PI is a multi-loop double PI 
																				PID is a single loop PID
*/
#define 				PID
//#define					PI
#define	 			 	limH				1410					/* upper saturation limit (98%)		  */
#define  			 	limL				30						/* lower saturation limit (2%)		  */


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */


__IO	uint16_t 				x1x2[2] = {0, 0};					/* ADC readouts								*/
__IO 	int16_t 				DutyCycle = 720;					/* TIM1	duty-cycle						*/
			uint16_t 				xRef = 0x800;							/* setpoint is half FSR				*/
/*
			Set point for x2 is upper limited to 0xD10 (3344) by maximum duty-cycle 
			and inverter saturation.
*/
			uint16_t  			x1_ref = 0x800;				 	  /* x1 set-point (internal)		*/
			int16_t					e2o	= 0;									/* error2(k-1)								*/
/* -------------------------------------------------------------------------- */			
#ifdef PI
			int16_t 				error1 = 0;            		/* error on state variable x1 */
			uint16_t  			kp1 = 6000;								/* proportional gain 1 				*/
			uint16_t  			ki1 = 500;								/* integral gain 1 						*/
			int32_t					yint1	= 0;								/* integral output 1					*/
			int32_t	 				yp1 = 0;									/* proportional output 1			*/
			uint16_t  			kp2 = 6000;								/* proportional gain 2 				*/
			uint16_t  			ki2 = 400;								/* integral gain 2 					 	*/
#endif			
			int16_t 				error2 = 0;            		/* error on state variable x2 */
			int32_t					yint2	= 0;								/* integral output 2					*/
			int32_t	 				yp2 = 0;									/* proportional output 2			*/
/* -- PID gains ------------------------------------------------------------- */
#ifdef PID
			uint16_t  			kp2 = 1400;								/* proportional gain  				*/
			uint16_t  			ki2 = 300;								/* integral gain  					 	*/
			uint16_t				kd2	=	1700;								/* derivative gain  				 	*/
			int32_t					yd2 = 0;									/* derivative output 					*/
#endif			


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/

extern DMA_HandleTypeDef hdma_adc1;
extern uint32_t ADCdata;

/* USER CODE BEGIN EV */

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M3 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */

  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Prefetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */

  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F1xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f1xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles DMA1 channel1 global interrupt.
  */
void DMA1_Channel1_IRQHandler(void)
{
  /* USER CODE BEGIN DMA1_Channel1_IRQn 0 */

  /* USER CODE END DMA1_Channel1_IRQn 0 */
  
	HAL_DMA_IRQHandler(&hdma_adc1);
  
	/* USER CODE BEGIN DMA1_Channel1_IRQn 1 */
	
		x1x2[0] = (ADCdata&0x0000FFFF);			/* Chn0	readout											*/
		x1x2[1] = (ADCdata >> 16);					/* Chn1	readout											*/
	
#ifdef PID
/*
		---- Variable x2 --------------------------------------------------------
*/
		error2 = (xRef - x1x2[1]);					/* error on output voltage					*/
/*	
		PID regulator -----------------------------------------------------------
*/		
		yp2	 	= (kp2*error2)>>16;						/* proportional part 								*/
		yint2 += ki2*error2;								/* integral part update (32 bit)		*/
		yd2 = (kd2*(error2-e2o))>>16;				/* derivative part 									*/
		e2o = error2;												/* update sample at k-1							*/
		
		DutyCycle = yp2 + (yint2>>16) + yd2;
/*	
		Output saturation (if any) -----------------------------------------------
*/	
		if (DutyCycle <= limL) 							/* check lower limit								*/
		{
				DutyCycle = limL;
				yint2 = (limL<<16);
		}
		if (DutyCycle >= limH) 							/* check upper limit								*/
		{
				DutyCycle = limH;
				yint2 = (limH<<16);
		}
/*
		--------------------------------------------------------------------------
*/			 	
#endif

#ifdef PI
/*
		---- Variable x2 (voltage on C) ------------------------------------------
*/
		error2 = xRef - x1x2[1];             		/* error on x2						   		*/
/*	
		PI regulator -------------------------------------------------------------
*/		
		yp2	 	= (kp2*error2)>>16;								/* proportional part						*/
		yint2 += ki2*error2;										/* integral part update (32 bit)*/
		x1_ref = yp2 + (yint2>>16);							/* update x1_ref								*/ 
/*
		---- Variable x1 (current on L) -----------------------------------------
*/
		error1 = x1_ref - x1x2[0];           		/* error on x1							  	*/
/*	
		PI regulator -------------------------------------------------------------
*/		
		yp1	 	= (kp1*error1)>>16;								/* proportional part						*/
		yint1 += ki1*error1;										/* integral part update	(32 bit)*/
/*	
		--------------------------------------------------------------------------
*/
		DutyCycle = yp1 + (yint1>>16);
/*	
		Output saturation (if any) -----------------------------------------------
*/	
		if (DutyCycle <= limL) 									/* check lower limit						*/
		{
				DutyCycle = limL;
				yint1 = 0;
		}
		if (DutyCycle >= limH) 									/* check upper limit						*/
		{
				DutyCycle = limH;
				yint1 = 0;
		}
#endif		
/*
		Duty-Cycle update
*/		
		TIM1->CCR1 = DutyCycle;
	
  /* USER CODE END DMA1_Channel1_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
