/**
  ******************************************************************************
  * @file    Filters\stm32f3xx_hal_msp.c
  * @author  Simone Buso
  * @version V1.1
  * @date    06-11-2016
  * @brief   HAL MSP module.
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

void HAL_HRTIM_MspInit(HRTIM_HandleTypeDef *hhrtim)
{
  RCC_PeriphCLKInitTypeDef 	PeriphClkInit;
  
  /* Use the PLLx2 clock for HRTIM */
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_HRTIM1;
  PeriphClkInit.Hrtim1ClockSelection = RCC_HRTIM1CLK_PLLCLK;
  HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit);
  
  /* Enable HRTIM clock*/
  __HRTIM1_CLK_ENABLE();

}


/**
  * @brief ADC MSP Initialization
  *        This function configures the hardware resources used in this example:
  *           - Peripheral's clock enable
  *           - Peripheral's GPIO Configuration
  * @param hadc: ADC handle pointer
  * @retval None
  */
void HAL_ADC_MspInit(ADC_HandleTypeDef *hadc)
{
  GPIO_InitTypeDef	GPIO_InitStruct;

  /*##-1- Enable peripherals and GPIO Clocks #################################*/
  /* Enable GPIO clock ****************************************/
	__GPIOB_CLK_ENABLE();
	__GPIOC_CLK_ENABLE();

  /* ADC2 Periph clock enable */
  __ADC12_CLK_ENABLE();
  /* ADC2 dedicated asynchronous clock enable */
  __HAL_RCC_ADC12_CONFIG(RCC_ADC12PLLCLK_DIV1);

  /*##-2- Configure peripheral GPIO ##########################################*/
  /* ADC Channel GPIO pin configuration
	
			PB2			------> ADC2_IN12
			PC5     ------> ADC2_IN11 
	
	*/
	GPIO_InitStruct.Pin = u2_s_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(u2_s_GPIO_Port, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = u1_s_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(u1_s_GPIO_Port, &GPIO_InitStruct);
		
  /*##-3- Configure the NVIC #################################################*/
	
	HAL_NVIC_SetPriority(ADC1_2_IRQn, 1, 0);
	HAL_NVIC_EnableIRQ(ADC1_2_IRQn);
}

void HAL_DAC_MspInit(DAC_HandleTypeDef* hdac)
{

  GPIO_InitTypeDef GPIO_InitStruct;
	
  if(hdac->Instance==DAC1)
  {
    /* Peripheral clock enable */
    __HAL_RCC_DAC1_CLK_ENABLE();
  
    /**DAC1 GPIO Configuration    
    PA4     ------> DAC1_OUT1
    PA5     ------> DAC1_OUT2 
    */
		__GPIOA_CLK_ENABLE();
		
    GPIO_InitStruct.Pin = DAC1_OUT1_Pin|DAC1_OUT2_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(DAC1_OUT1_GPIO_Port, &GPIO_InitStruct);
  }

}

/***************************** END OF FILE ************************************/
