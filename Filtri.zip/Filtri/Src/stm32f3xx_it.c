/**
	******************************************************************************
  * @file    Filters\stm32f3xx_it.c 
  * @author  Simone Buso
  * @version V1.8
  * @date    16-11-2016
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  */
/*	
	 Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f3xx_it.h"


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/**/
__IO  uint16_t  			u1 = 0;										/* u1 read-out								*/
__IO  uint16_t  			u2 = 0;										/* u2 read-out								*/
/* -------------------------------------------------------------------------- 			
		Low pass filter coefficients: filter time constant is 16 times the 
		sampling period, i.e. 320 us. Expected settling time is around 1.2 ms.	
		Cut-off frequency is around 500 Hz (530 Hz).	
*/			
			uint16_t				a1 = 61439;								/* filter coefficient #a			*/
			uint16_t				b1 = 4096;								/* filter coefficient #b			*/
/* -------------------------------------------------------------------------- */			
			uint32_t				y1 = 0;										/* low pass output at step k	*/
			uint32_t				y1o = 0;									/* low pass output at k-1			*/
			uint32_t				y2 = 0;										/* low pass output at step k	*/
			uint32_t				y2o = 0;									/* low pass output at k-1			*/
/*
   Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
//
/******************************************************************************/
/*                 STM32F3xx Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) , for the  			*/
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f3xx.s).                                               */
/******************************************************************************/

/**
  * @brief  	This function handles ADC2 interrupt request. This is where the
							filter and control routines are executed.
  * @param  	None
  * @retval 	None
  */
/**
  * @}
  */ 
void ADC1_2_IRQHandler(void)
{
	// Set the monitor pin
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_SET);
	
	// Manage the interrupt request via HAL library: very heavy!
	HAL_ADC_IRQHandler(&AdcHandle);
 
	//	Get the input signal samples
	u1 = HAL_ADCEx_InjectedGetValue(&AdcHandle, ADC_INJECTED_RANK_1);
	u2 = HAL_ADCEx_InjectedGetValue(&AdcHandle, ADC_INJECTED_RANK_2);

	//	First order low pass and high pass filter, complementary
		y1 = (b1*(u1<<4) + a1*y1o)>>16;
		y1o = y1;
	//	
		y2 = (b1*(u2<<4) + a1*y2o)>>16;
		y2o = y2;
		y2 = (u2<<4) - y2 + 0x8000;

	
	// Copy output to DAC1 channels #1 and #2		
		HAL_DACEx_DualSetValue(&hdac1, DAC_ALIGN_12B_L, y1, y2);
	
	//	Reset the monitor pin	
		HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, GPIO_PIN_RESET);	
}
/**
  * @}
  */
/******************************** END OF FILE ************************************/
