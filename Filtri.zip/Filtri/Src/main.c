/**
  ******************************************************************************
  * @file    Filters\main.c 
  * @author  Simone Buso
  * @version V1.2
  * @date    16-11-2016
  * @brief   Filter firmware main program
  ******************************************************************************
**/

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
int main(void)
{
  /* 
		STM32F3xx HAL library initialization:
       - Configure the Flash prefetch
       - Configure the Systick to generate an interrupt each 1 msec
       - Set NVIC Group Priority to 4
       - Global MSP (MCU Support Package) initialization
  */
  HAL_Init();
	//
  /* Configure the system clock to have a clock frequency = 72 MHz */
  SystemClock_Config();
	//
  /* Initialize DAC  */
  DAC_Config();
	//
  /* Initialize ADC to be triggered by the HRTIMER */
  ADC_Config();
  //
  /* Initialize HRTIMER and related inputs */
  HRTIM_Config();
  //
	/* Infinite loop */
  while (1) {}
}
 /*
	*
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
	*/
void Error_Handler(void)
{
  /* Turn LED2 on */
  BSP_LED_On(LED2);
  while(1) {}
}	
/***************************** END OF FILE ************************************/
