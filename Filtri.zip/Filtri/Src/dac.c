/**
  *****************************************************************************
  * @file    Filters\dac.c 
  * @author  Simone Buso
  * @version V1.1
  * @date    06-11-2016
  * @brief   Configuration of the STM32F334R8 DAC converter #1
  *****************************************************************************
**/

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Exported variables --------------------------------------------------------*/
DAC_HandleTypeDef hdac1;

/*
	*
  * @brief  Configure DAC1 
  * @param  None
  * @retval None
  */
void DAC_Config(void)
{
DAC_ChannelConfTypeDef sConfig;
  /* 
	DAC1 Initialization:
			- Call the HAL_DAC_Init function
			- HAL_DAC_Init calls HAL_DAC_MspInit
			- HAL_DAC_MspInit defines clock and pins for the DAC
	*/
  hdac1.Instance = DAC1;
  if (HAL_DAC_Init(&hdac1) != HAL_OK)
  {
    Error_Handler();
  }
  /*
			Here the DAC is configured 
	
			DAC channel OUT #1 config 
  */
  sConfig.DAC_Trigger = DAC_TRIGGER_NONE;
  sConfig.DAC_OutputBuffer = DAC_OUTPUTBUFFER_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac1, &sConfig, DAC_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /*
			DAC channel OUT #2 config 
  */
  sConfig.DAC_OutputSwitch = DAC_OUTPUTSWITCH_ENABLE;
  if (HAL_DAC_ConfigChannel(&hdac1, &sConfig, DAC_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
	/*
			Start the DAC now
	*/
	HAL_DAC_Start(&hdac1, DAC_CHANNEL_1);
	HAL_DAC_Start(&hdac1, DAC_CHANNEL_2);
}
