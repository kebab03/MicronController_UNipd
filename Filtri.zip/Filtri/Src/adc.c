/**
  *****************************************************************************
  * @file    Filters\adc.c 
  * @author  Simone Buso
  * @version V1.1
  * @date    11-11-2016
  * @brief   Set-up of the STM32F334R8 A/D converter #2
  *****************************************************************************
**/

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f3xx_hal.h"

/* Exported variables --------------------------------------------------------*/
ADC_HandleTypeDef AdcHandle;

/**
	*
  * @brief  Configure ADC2 for being used with HRTIM
  * @param  None
  * @retval None
 **/
void ADC_Config(void)
{
  ADC_MultiModeTypeDef MultiModeConfig;
  ADC_InjectionConfTypeDef InjectionConfig;

  AdcHandle.Instance = ADC2;

  /* 
		ADC2 is working independently 
	*/
  MultiModeConfig.DMAAccessMode = ADC_DMAACCESSMODE_DISABLED;
  MultiModeConfig.Mode = ADC_MODE_INDEPENDENT;
  MultiModeConfig.TwoSamplingDelay = ADC_TWOSAMPLINGDELAY_1CYCLE;
  HAL_ADCEx_MultiModeConfigChannel(&AdcHandle, &MultiModeConfig);
  /* 
		---------------------------------------------------
			ADC2 global initialization
		---------------------------------------------------
	*/
  /* 
		 12-bit right-aligned format, running from PLL 
	*/
  AdcHandle.Init.ClockPrescaler = ADC_CLOCK_ASYNC;
  AdcHandle.Init.Resolution = ADC_RESOLUTION12b;
  AdcHandle.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  AdcHandle.Init.ScanConvMode = ENABLE;
  AdcHandle.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  AdcHandle.Init.LowPowerAutoWait = DISABLE;
  AdcHandle.Init.ContinuousConvMode = DISABLE;
  AdcHandle.Init.NbrOfConversion = 0;
  AdcHandle.Init.DiscontinuousConvMode = DISABLE;
  AdcHandle.Init.NbrOfDiscConversion = 0;
  AdcHandle.Init.ExternalTrigConv = ADC_SOFTWARE_START;
	AdcHandle.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  AdcHandle.Init.DMAContinuousRequests = DISABLE;
  AdcHandle.Init.Overrun = OVR_DATA_OVERWRITTEN;
  /*
		Call the HAL library ADC initialization function. 
		The HAL_ADC_Init function calls the HAL_ADC_MspInit function 
		that defines the clock and the (application specific) GPIO pins
		used by the ADC.	
	*/
	HAL_ADC_Init(&AdcHandle);
  /* 
		Configuration of the sampling sequence
	
		Discontinuous injected mode: ADC inputs are sampled 
		once per PWM period (i.e. @ 50kHz)

		Rank 1: ADC2_IN11 <- PC5
		Rank 2: ADC2_IN12	<- PB2
	*/
  InjectionConfig.InjectedNbrOfConversion = 2;
  InjectionConfig.InjectedDiscontinuousConvMode = DISABLE;					// Important!! IRQ is raised at each trigger event
	InjectionConfig.AutoInjectedConv = DISABLE;
  InjectionConfig.QueueInjectedContext = DISABLE;
	InjectionConfig.ExternalTrigInjecConv = ADC_EXTERNALTRIGINJECCONV_HRTIM_TRG2;
  InjectionConfig.ExternalTrigInjecConvEdge = ADC_EXTERNALTRIGINJECCONV_EDGE_RISING;
	/* 
			Configure the 1st injected conversion 
	*/	
	InjectionConfig.InjectedChannel = ADC_CHANNEL_11;
  InjectionConfig.InjectedRank = ADC_INJECTED_RANK_1;
  InjectionConfig.InjectedSamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  InjectionConfig.InjectedSingleDiff = ADC_SINGLE_ENDED;
  InjectionConfig.InjectedOffsetNumber = ADC_OFFSET_NONE;
  InjectionConfig.InjectedOffset = 0;
	//
  HAL_ADCEx_InjectedConfigChannel(&AdcHandle, &InjectionConfig);
  /* 
			Configure the 2nd injected conversion 
			(all other parameters are identical) 
	*/
  InjectionConfig.InjectedChannel = ADC_CHANNEL_12;
  InjectionConfig.InjectedRank = ADC_INJECTED_RANK_2;
  //
	HAL_ADCEx_InjectedConfigChannel(&AdcHandle, &InjectionConfig);
	/*
			Run the ADC calibration in single-ended mode 
	*/
  HAL_ADCEx_Calibration_Start(&AdcHandle, ADC_SINGLE_ENDED);
  /* 
			Start ADC2 Injected Conversions 
	*/ 
  HAL_ADCEx_InjectedStart_IT(&AdcHandle);
}
