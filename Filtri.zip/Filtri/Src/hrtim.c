/**
  ******************************************************************************
  * @file    Filters\hrtim.c 
  * @author  Simone Buso
  * @version V1.1
  * @date    06-11-2016
  * @brief   Set-up of the STM32F334R8 high resolution timer (HRTim)
  ******************************************************************************
**/

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Exported variables --------------------------------------------------------*/
HRTIM_HandleTypeDef hhrtim;
/**
*
* @brief  HRTIMER configuration for PWM on CHA1
* @param  None
* @retval None
**/
void HRTIM_Config(void)
{
  HRTIM_TimeBaseCfgTypeDef 		TimebaseConfig;				// pointer to HRTIM timebase configuration registers
  HRTIM_TimerCfgTypeDef 			TimerConfig;					// pointer to HRTIM general configuration registers
  HRTIM_OutputCfgTypeDef 			OutputConfig;  				// pointer to HRTIM output configuration registers
  HRTIM_CompareCfgTypeDef 		CompareConfig;				// pointer to HRTIM compare registers
  HRTIM_ADCTriggerCfgTypeDef 	AdcTriggerConfig;			// pointer to HRTIM trigger configuration registers
	GPIO_InitTypeDef 						GPIO_InitStruct;			// GPIO configuration structure
  /*
		----------------------------
		HRTIM Global initialization 
		----------------------------
	
		Initialize the HRTIM structure (minimal configuration) 
	
	*/
  hhrtim.Instance = HRTIM1;
  hhrtim.Init.HRTIMInterruptResquests = HRTIM_IT_NONE;
  hhrtim.Init.SyncOptions = HRTIM_SYNCOPTION_NONE;
  /* 
	Initialize HRTIM: the following function calls the HAL_HRTIM_MspInit function 
	that initializes the GPIO inputs, the HRTIM clock, the NVIC and the DMA (if needed).
	*/
  HAL_HRTIM_Init(&hhrtim);
  /* 
	HRTIM DLL calibration: periodic calibration, set period to 14�s 
	*/
  HAL_HRTIM_DLLCalibrationStart(&hhrtim, HRTIM_CALIBRATIONRATE_14);
  /*
	Wait calibration completion	
	*/
  if (HAL_HRTIM_PollForDLLCalibration(&hhrtim, 100) != HAL_OK)
  {
    Error_Handler(); // if DLL or clock is not correctly set
  }
  /* 
		--------------------------------------------------- 
		TIMER initialization: timer mode and PWM frequency  
		--------------------------------------------------- 
	*/
  TimebaseConfig.Period = MODPER;															// 50 kHz sampling frequency
  TimebaseConfig.PrescalerRatio = HRTIM_PRESCALERRATIO_MUL16;
  TimebaseConfig.Mode = HRTIM_MODE_CONTINUOUS;
	/**/
	HAL_HRTIM_TimeBaseConfig(&hhrtim, HRTIM_TIMERINDEX_TIMER_A, &TimebaseConfig);
	/*
	
	 ----------------------------------------------------------------------- 
   TIMER global configuration: cnt reset, sync, update, fault, burst...  
   ----------------------------------------------------------------------- 
	 
	*/
	TimerConfig.DMARequests = HRTIM_TIM_DMA_NONE;
  TimerConfig.DMASrcAddress = 0x0;
  TimerConfig.DMADstAddress = 0x0;
  TimerConfig.DMASize = 0x0;
  TimerConfig.HalfModeEnable = HRTIM_HALFMODE_DISABLED;
  TimerConfig.StartOnSync = HRTIM_SYNCSTART_DISABLED;
  TimerConfig.ResetOnSync = HRTIM_SYNCRESET_DISABLED;
  TimerConfig.DACSynchro = HRTIM_DACSYNC_NONE;
  TimerConfig.PreloadEnable = HRTIM_PRELOAD_DISABLED; 
  TimerConfig.UpdateGating = HRTIM_UPDATEGATING_INDEPENDENT;
  TimerConfig.BurstMode = HRTIM_TIMERBURSTMODE_MAINTAINCLOCK;
  TimerConfig.RepetitionUpdate = HRTIM_UPDATEONREPETITION_ENABLED;
  TimerConfig.ResetUpdate = HRTIM_TIMUPDATEONRESET_DISABLED;
  TimerConfig.InterruptRequests = HRTIM_TIM_IT_NONE;
  TimerConfig.PushPull = HRTIM_TIMPUSHPULLMODE_DISABLED;
  TimerConfig.FaultEnable = HRTIM_TIMFAULTENABLE_NONE;
  TimerConfig.FaultLock = HRTIM_TIMFAULTLOCK_READWRITE;
  TimerConfig.DeadTimeInsertion = HRTIM_TIMDEADTIMEINSERTION_DISABLED;
  TimerConfig.DelayedProtectionMode = HRTIM_TIMDELAYEDPROTECTION_DISABLED;
  TimerConfig.UpdateTrigger= HRTIM_TIMUPDATETRIGGER_NONE;
	TimerConfig.ResetTrigger = HRTIM_TIMRESETTRIGGER_NONE;
	HAL_HRTIM_WaveformTimerConfig(&hhrtim, HRTIM_TIMERINDEX_TIMER_A, &TimerConfig);	
/*
		--------------------------------------------- 
		TA1 waveform description  	
		---------------------------------------------
*/
  OutputConfig.Polarity = HRTIM_OUTPUTPOLARITY_HIGH;
  OutputConfig.SetSource = HRTIM_OUTPUTSET_TIMPER;
  OutputConfig.ResetSource = HRTIM_OUTPUTRESET_TIMCMP1;
  OutputConfig.IdleMode = HRTIM_OUTPUTIDLEMODE_NONE;
  OutputConfig.IdleLevel = HRTIM_OUTPUTIDLELEVEL_INACTIVE;
  OutputConfig.FaultLevel = HRTIM_OUTPUTFAULTLEVEL_NONE;
  OutputConfig.ChopperModeEnable = HRTIM_OUTPUTCHOPPERMODE_DISABLED;
  OutputConfig.BurstModeEntryDelayed = HRTIM_OUTPUTBURSTMODEENTRY_REGULAR;
	/**/
  HAL_HRTIM_WaveformOutputConfig(&hhrtim, 
																	HRTIM_TIMERINDEX_TIMER_A, 
																	HRTIM_OUTPUT_TA1, 
																	&OutputConfig);
  /* 
			Set compare registers for duty cycle and ADC trigger event
	*/
	CompareConfig.CompareValue = DUTY;
	/**/
  HAL_HRTIM_WaveformCompareConfig(&hhrtim, 
																	HRTIM_TIMERINDEX_TIMER_A, 
																	HRTIM_COMPAREUNIT_1, 
																	&CompareConfig);
	/**/
	CompareConfig.CompareValue = (DUTY/2);
	/**/
	HAL_HRTIM_WaveformCompareConfig(&hhrtim, 
																	HRTIM_TIMERINDEX_TIMER_A, 
																	HRTIM_COMPAREUNIT_2, 
																	&CompareConfig);
	/*
		---------------------------------------------------
			ADC trigger intialization (CMP2 register) 				
		---------------------------------------------------
	 
			Set compare 2 register for 1st ADC trigger 
	*/
  AdcTriggerConfig.Trigger = HRTIM_ADCTRIGGEREVENT24_TIMERA_CMP2;
  AdcTriggerConfig.UpdateSource = HRTIM_ADCTRIGGERUPDATE_TIMER_A;
  HAL_HRTIM_ADCTriggerConfig(&hhrtim,
                             HRTIM_ADCTRIGGER_2,
                             &AdcTriggerConfig);
	/* 
		---------------------------------------------------
					HRTIM start-up 	
		---------------------------------------------------
				
		Start HRTIM's TIMER A
	*/
  HAL_HRTIM_WaveformCounterStart_IT(&hhrtim, HRTIM_TIMERID_TIMER_A);
	/* 
		Now enable GPIO clock for HRTIMER outputs 
	*/
	__GPIOA_CLK_ENABLE(); 
	
	/* Configure GPIO PA.9 as a service pin    
			PA9     ------> monitor pin
  */
	GPIO_InitStruct.Pin = GPIO_PIN_9;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;	
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
}
