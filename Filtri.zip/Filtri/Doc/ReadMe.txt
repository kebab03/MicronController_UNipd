Test di filtri numerici elementari

Obiettivo: realizzare e sperimentare filtri numerici di tipo passa-basso e passa-alto del primo ordine
Strumenti: mCTb e uVision 5

-----------------------------------------------------------------------------------------------------
Configurazione

I segnali di ingresso ad onda quadra, generati da uno strumento apposito, sono applicati agli ingressi
ExtInp1 e ExtInp2 della scheda mCTb.
Le uscite dei due filtri numerici vengono convertite in livelli di tensione dal DAC1, sui canali #1 e #2. 
I pin di uscita sono indicati con DACOut1 e DACOut2.
Per semplicit�, i due filtri sono realizzati in forma complementare, sicch� il passa-alto � ricavato per
differenza dal passa-basso.

------------------------------------------------------------------------------------------------------
Risorse impiegate

Si impiega HRTIM come sorgente di trigger per ADC2.
ADC2 converte i due canali di ingresso #11 e #12 in successione.
DAC1 viene invece usato per visualizzare i segnali di uscita del filtro.

La gestione di ADC2 � per interruzioni.
La gestione di DAC1 avviene invece in polling.

------------------------------------------------------------------------------------------------------
Debugging

Il canale #2 � ora funzionante dopo l'apertura del ponticello SB21 sulla scheda Nucleo (11/17/2016).
Le risposte del filtro passa-basso e passa-alto sono correttamente visualizzate all'oscilloscopio
(11/17/2016). Verificata la corrispondenza tra banda passante di progetto e tempo di assestamento.
C'� un problema (minor) di scorrimento dei campioni sul passa-alto, che manda in errore la
ricostruzione del segno, per cui occasionalmente compare uno spike, sul fronte negativo.


