/**
  ******************************************************************************
  * @file    Filters/main.h 
  * @author  Simone Buso
  * @version V1.0
  * @date    26-08-2016
  * @brief   Header file for source modules
  ******************************************************************************
 *
 */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f3xx_hal.h"
#include "stm32f3xx_nucleo.h"

/* Exported constants --------------------------------------------------------*/
//
#define MODPER 					((uint16_t)46080) 	 // sampling period in clock ticks
#define DUTY  					((uint16_t)MODPER/2) // default duty-cycle: 0.5
//
#define DAC1_OUT1_Pin 			GPIO_PIN_4
#define DAC1_OUT1_GPIO_Port GPIOA
#define DAC1_OUT2_Pin 			GPIO_PIN_5
#define DAC1_OUT2_GPIO_Port GPIOA
#define x1_s_Pin						GPIO_PIN_6
#define x1_s_GPIO_Port 			GPIOA
#define x2_s_Pin 						GPIO_PIN_7
#define x2_s_GPIO_Port 			GPIOA
#define u1_s_Pin	 					GPIO_PIN_5
#define u1_s_GPIO_Port 			GPIOC
#define u2_s_Pin						GPIO_PIN_2
#define	u2_s_GPIO_Port			GPIOB
#define PWM_Pin 						GPIO_PIN_8
#define PWM_GPIO_Port 			GPIOA

/* Exported variables --------------------------------------------------------*/

extern HRTIM_HandleTypeDef hhrtim;
extern ADC_HandleTypeDef AdcHandle;
extern DAC_HandleTypeDef hdac1;

/* Exported macro ------------------------------------------------------------*/

/* Exported functions --------------------------------------------------------*/

extern void SystemClock_Config(void);
extern void HRTIM_Config(void);
extern void ADC_Config(void);
extern void DAC_Config(void);
extern void Error_Handler(void);

#endif /* __MAIN_H */

/******************************** END OF FILE *********************************/
